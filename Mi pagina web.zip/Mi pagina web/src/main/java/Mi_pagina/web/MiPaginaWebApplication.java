package Mi_pagina.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiPaginaWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiPaginaWebApplication.class, args);
	}

}
